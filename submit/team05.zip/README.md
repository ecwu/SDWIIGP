# SDWIIGP
Software Development Workshiop II Group Project
***


Current Status: `Finished`

## How to deploy
1. install requirements using pip
`pip install --user -r requirements.txt`

2. Open the `sourcecode` folder using PyCharm or Just go to the `sourcecode` folder using command `python manage.py runserver`

## Project Basic Information
![GMS Black Icon](design/img/logo_t_black.png)

A Gym management System

## Author

Zhenghao Wu (1630003054)

Qizhou Xie (1630003056)
