from django.apps import AppConfig


class OperationConfig(AppConfig):
    name = 'operation'
