from django.apps import AppConfig


class CreateConfig(AppConfig):
    name = 'create'
